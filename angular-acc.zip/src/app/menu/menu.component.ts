import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatSidenav } from '@angular/material';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  @ViewChild('sidenav',{static: false}) sidenav: MatSidenav;
  @Input() isExpanded = true;
   showSubmenu: boolean = false;
   @Input() isShowing = false;
  showSubSubMenu: boolean = false;
  
  constructor() { }

  ngOnInit() {
  }

}
